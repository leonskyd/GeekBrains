package lesson1;

public class Main {
    public static void main(String[] args) {


        testVars();
        System.out.println(calculateExp(4, 2, 3,2));
        System.out.println(checkSum(10, 11));
        checkNumber(-7);
        System.out.println(isItNegitive(5));
        //sayMyName('Denis');


    }

    static void testVars(){
        int valA = 10;
        int valB = 8;
        int result = valA * valB;
        System.out.println(result);

        double doubleA = 12.25;
        double doubleB = 5.85;
        double doubleResult = doubleA / doubleB;
        System.out.println(doubleResult);


    }

    static int calculateExp(int a, int b, int c, int d) {
        int result = a * (b + (c / d));
        if (d != 0) {
            System.out.println(result);
        }
        else {
            System.out.println("int d cannot be a zero");
        }
        return result;

    }


    static boolean checkSum(int a, int b) {
        int sumResult = a + b;
        boolean isTrue = true;
        boolean isFalse = false;
        if (sumResult >= 10 && sumResult <= 20) {
            return isTrue;
        } else {
            return isFalse;
        }
    }

    static void checkNumber(int a) {
        if (a >= 0) {
            System.out.println("The number is positive");
        }
        else {
            System.out.println("The number is negative");
        }
    }

    static boolean isItNegitive(int a) {
        boolean isTrue = true;
        boolean isFalse = false;
        if (a < 0) {
            return isTrue;
        }
        else {
            return isFalse;
        }
    }

    static void sayMyName(char a) {
        String str = "Hello";
        System.out.println(str + "char a");
    }



   }
